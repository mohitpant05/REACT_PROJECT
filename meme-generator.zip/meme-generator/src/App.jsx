import React from "react"
import './App.css'
import Header from '../Component/Header'
import Meme from "../Component/Meme"
// import Form from "../Component/Form.jsx"
export default function App() {
    
    return (<>
      <Header/>
      <Meme />
      {/* <Form /> */}
      </>
    )
}