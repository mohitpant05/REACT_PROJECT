

let arr=[1,2,3,4,5,5,3,22,1,1,3,4,5]

let arr1 = arr.sort((a,b)=>{
    return a-b})
console.log(arr1)


let arrd = "Mohit"
let arrl="Pant"
let arrt=[...arrd," ",...arrl]
console.log(arrt)