import React from "react";
import './comp.css'

function Content(){
    return(<>
    <main className="content">
    <h1 className="content-heading">Fun Facts about React</h1>

    <ul className="ul">
        <li className="content-list">Was first released in 2013</li>
        <li className="content-list">Was originally created by Jordan Walke</li>
        <li className="content-list">Has well over 100K stars on Github</li>
        <li className="content-list">Is maintained by Facebook</li>
        <li className="content-list">Powers thousands of enterprise apps, including mobile apps</li>
    </ul>
    </main>


    </>)
}

export default Content