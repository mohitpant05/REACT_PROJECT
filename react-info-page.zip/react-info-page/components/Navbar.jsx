import React from "react";
import './comp.css'

function Navbar(){
return(<>
<nav><img src="../src/assets/react.svg" alt="react-logo" />
<h1>React Facts</h1>

<h2>React Course- Project 1</h2>
</nav>



</>)
}

export default Navbar;