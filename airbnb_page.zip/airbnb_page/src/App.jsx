import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Navbar from '../component/Navbar'
import Hero from '../component/Hero'
import Card from '../component/Card'
import FunProps from '../component/FunProps'
import ContactPage from '../Contact/ContactPage'
import Ata from '../component/Data'

function App() {
  let data=Ata.map((item)=>{
    return <Card 
    img={item.coverImg}
    rating={item.stats.rating}
    reviewCount={item.stats.reviewCount}
    location={item.location}
    title={item.title}
    price={item.price}
    openSpots={item.openSpots}/>
  })



  return (
    <>
    <Navbar />
    <Hero />
    <div className="cards-list">{data}</div>
 
   
    {/* <FunProps/> */}
    {/* <ContactPage img="./src/assets/pumpkin.png" name="Pumpkin" phone="(0800) CAT KING" mail="pumpkin@scrimba.com"/>
    <ContactPage img="./src/assets/pumpkin.png" name="Pumpkin" phone="(0800) CAT KING" mail="pumpkin@scrimba.com"/>
    <ContactPage img="./src/assets/pumpkin.png" name="Pumpkin" phone="(0800) CAT KING" mail="pumpkin@scrimba.com"/>
    <ContactPage img="./src/assets/pumpkin.png" name="Pumpkin" phone="(0800) CAT KING" mail="pumpkin@scrimba.com"/> */}

    </>
  )
}

export default App

{/* <div className="contact-card">
<img src="./src/assets/pumpkin.png" className="main"/>
<h3>Pumpkin</h3>
<div className="info-group">
    <img src="./src/assets/phone-icon.png" />
    <p>(0800) CAT KING</p>
</div>
<div className="info-group">
    <img src="./src/assets/mail-icon.png" />
    <p>pumpkin@scrimba.com</p>
</div>
</div> */}
