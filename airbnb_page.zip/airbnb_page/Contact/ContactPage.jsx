import React from "react";
import './ContactPage.css'

export default function ContactPage(props){
    
    return(<>
    {/* <div className="contacts">
    <div className="contact-card">
                <img src="./src/assets/felix.png" className="main"/>
                <h3>Felix</h3>
                <div className="info-group">
                    <img src="./src/assets/phone-icon.png" />
                    <p>(212) 555-4567</p>
                </div>
                <div className="info-group">
                    <img src="./src/assets/mail-icon.png" />
                    <p>thecat@hotmail.com</p>
                </div>
            </div>
            
            <div className="contact-card">
                <img src="./src/assets/mr-whiskerson.png" className="main"/>
                <h3>Mr. Whiskerson</h3>
                <div className="info-group">
                    <img src="./src/assets/phone-icon.png" />
                    <p>(212) 555-1234</p>
                </div>
                <div className="info-group">
                    <img src="./src/assets/mail-icon.png" />
                    <p>mr.whiskaz@catnap.meow</p>
                </div>
            </div>
            
            <div className="contact-card">
                <img src="./src/assets/fluffykins.png" className="main"/>
                <h3>Fluffykins</h3>
                <div className="info-group">
                    <img src="./src/assets/phone-icon.png" />
                    <p>(212) 555-2345</p>
                </div>
                <div className="info-group">
                    <img src="./src/assets/mail-icon.png" />
                    <p>fluff@me.com</p>
                </div>
            </div>
            
            <div className="contact-card">
                <img src="./src/assets/felix.png" className="main"/>
                <h3>Felix</h3>
                <div className="info-group">
                    <img src="./src/assets/phone-icon.png" />
                    <p>(212) 555-4567</p>
                </div>
                <div className="info-group">
                    <img src="./src/assets/mail-icon.png" />
                    <p>thecat@hotmail.com</p>
                </div>
            </div>
            
            <div className="contact-card">
                <img src="./src/assets/pumpkin.png" className="main"/>
                <h3>Pumpkin</h3>
                <div className="info-group">
                    <img src="./src/assets/phone-icon.png" />
                    <p>(0800) CAT KING</p>
                </div>
                <div className="info-group">
                    <img src="./src/assets/mail-icon.png" />
                    <p>pumpkin@scrimba.com</p>
                </div>
            </div>
            
            
            </div> */}

<div className="contacts">
    <div className="contact-card">
                <img src={props.img} className="main"/>
                <h3>{props.name}</h3>
                <div className="info-group">
                    <img src="./src/assets/phone-icon.png" />
                    <p>{props.phone}</p>
                </div>
                <div className="info-group">
                    <img src="./src/assets/mail-icon.png" />
                    <p>{props.mail}</p>
                </div>
            </div>
            </div>
            </>)

}