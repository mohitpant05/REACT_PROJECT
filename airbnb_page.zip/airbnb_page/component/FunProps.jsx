import React from "react";


function FunProps(){
    let date = new Date();
    let timeOfDay,message
    if(date.getHours()<12){
        timeOfDay=(date.getHours()%12)+ " "+ date.getMinutes();
        message = "Morning "
    }
    else if (date.getHours()>=12 && date.getHours()<=17) {
        
        timeOfDay=(date.getHours()%24)+ " "+ date.getMinutes();
        message = "AfterNoon "
    } else {
        
        timeOfDay=(date.getHours()%24)+ " "+ date.getMinutes();
        message = "Night "
    }

    return(<>
        <h1>It is about {timeOfDay} so It's Good {message} .</h1>
    </>)
}


export default FunProps