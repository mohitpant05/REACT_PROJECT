import React from "react";
import './Component.css'

function Card(props){
    let badge
    if(props.openSpots === 0){
        badge="SOLD OUT"
    }
    else if(props.location==="Online"){
        badge="ONLINE"
    }
    else{
        badge=false
    }

    return (
        <div className="card">
            {badge && <div className="sold-out">{badge}</div>}
            
            <img src={props.img} className="card--image" />
            <div className="card--stats">
                <img src="/src/assets/1star.png" className="card--star" />
                <span>{props.rating}</span>
                <span className="gray">({props.reviewCount}) • </span>
                <span className="gray">{props.location}</span>
            </div>
            <p className="card--title">{props.title}</p>
            <p className="card--price"><span className="bold">From ${props.price}</span> / person</p>
        </div>
    )
}

export default Card;