import React from "react";
import './Component.css'

function Hero(){
return(<>
<div className="hero1">
    <img src="/src/assets/Group 77.jpg" alt="group image" className="hero" />
    </div>
    <h1>Online Experiences</h1>
            <p>Join unique interactive activities led by 
            one-of-a-kind hosts—all without leaving home.</p>
</>)
}

export default Hero