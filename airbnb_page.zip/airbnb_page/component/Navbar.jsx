import React from "react";
import './Component.css'
import Hero from "./Hero";

function  Navbar(){
    return(
        <>
        <div className="container">
        <nav>
            <img src="/src/assets/airbnb 1.jpg" alt="logo" />
        </nav></div>
        </>
    )
}

export default Navbar